SECRET_KEY = 'django-insecure-=_pzkx5k80+25sp4=i*%netd=semvimp3#%_yk712fgz$scn*9'
EMAIL_HOST_SENDER = 'goliyao09@gmail.com'
EMAIL_HOST_RECEIVER = 'huguescodeur@gmail.com'
EMAIL_HOST_PASSWORD = 'dqtylrxcwoflitis'
